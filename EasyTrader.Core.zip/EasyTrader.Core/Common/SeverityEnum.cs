﻿namespace EasyTrader.Core.Common
{
    public enum SeverityEnum
    {
        Error = 0,
        Warning = 1,
        Information = 2,
        Debug = 3,
    }
}
