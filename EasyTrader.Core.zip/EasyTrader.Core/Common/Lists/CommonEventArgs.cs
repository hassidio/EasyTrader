﻿namespace EasyTrader.Core.Common.Lists
{
    public class CommonEventArgs : EventArgs
    {
        public CommonEventArgs() { }

        public dynamic Args;
    }
}